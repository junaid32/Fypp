function customtext(){
	document.getElementById('intro-mess').style.paddingTop = "11.3%";
	document.getElementById('intro-mess').style.paddingBottom = "2%";
	document.getElementById('Custom-text').style.display = "block";

	
}
function customtextfb(){
	document.getElementById('intro-mess').style.paddingTop = "20%";
	document.getElementById('intro-mess').style.paddingBottom = "10.3%";
	document.getElementById('Custom-text').style.display = "none";
}
